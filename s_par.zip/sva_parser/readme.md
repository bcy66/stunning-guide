# SystemVerilog Assertion Parser

A Python-based parser for SystemVerilog Assertions (SVA) that extracts and analyzes property specifications, sequences, and assertions from SystemVerilog files.

## Features

- Parse SystemVerilog modules including parameters and ports
- Extract SVA properties, sequences, and assertions
- Analyze always blocks (including always_ff and always_comb)
- Parse assertions within generate blocks
- Intelligent signal extraction with SVA-specific construct handling
- Line number tracking for all extracted components
- Comprehensive error handling and logging

## Installation

1. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

## Usage

### Command Line Interface

Parse a SystemVerilog file and generate JSON output:
```bash
python -m src.parser input_file.sv -o output.json
```

Multiple files can be processed at once:
```bash
python -m src.parser file1.sv file2.sv -o output.json
```

Enable debug logging:
```bash
python -m src.parser input_file.sv -o output.json --debug
```

### Python API

```python
from src.parser import SVAParser

# Initialize parser
parser = SVAParser()

# Parse a file
results = parser.parse_file("path/to/file.sv")

# Access parsed components
module_info = results['module']
properties = results['properties']
sequences = results['sequences']
assertions = results['assertions']
```

## Development

### Running Tests

Run all tests:
```bash
python -m unittest discover tests
```

Run specific test files:
```bash
python -m unittest tests/test_parser.py
python -m unittest tests/test_signal_extractor.py
```

### Code Structure

- `src/parser.py`: Main parser implementation
- `src/signal_extractor.py`: Signal extraction logic
- `src/utils.py`: Utility functions
- `tests/`: Test files and test data

