"""Test cases for Signal Extractor."""

import unittest
from src.signal_extractor import SignalExtractor

class TestSignalExtractor(unittest.TestCase):
    """Test cases for SVA Signal Extractor."""

    def setUp(self):
        self.extractor = SignalExtractor()

    def test_system_functions(self):
        """Test handling of SVA system functions."""
        test_cases = [
            {
                'name': 'basic_system_functions',
                'input': '$rose(valid) |-> $stable(data)',
                'expected': {'valid', 'data'},
                'unexpected': {'$rose', '$stable'}
            },
            {
                'name': 'complex_functions',
                'input': '$past(req) |-> $onehot(state)',
                'expected': {'req', 'state'},
                'unexpected': {'$past', '$onehot'}
            }
        ]

        for test in test_cases:
            with self.subTest(name=test['name']):
                signals = self.extractor.extract_signals(test['input'])
                for expected in test['expected']:
                    self.assertIn(expected, signals)
                for unexpected in test['unexpected']:
                    self.assertNotIn(unexpected, signals)

    def test_repetition_operators(self):
        """Test handling of SVA repetition operators."""
        test_cases = [
            {
                'name': 'consecutive_repetition',
                'input': 'req [*3] |-> gnt',
                'expected': {'req', 'gnt'}
            },
            {
                'name': 'non_consecutive_repetition',
                'input': 'valid [=2] ##2 ready',
                'expected': {'valid', 'ready'}
            }
        ]

        for test in test_cases:
            with self.subTest(name=test['name']):
                signals = self.extractor.extract_signals(test['input'])
                self.assertEqual(signals, test['expected'])

    def test_context_extraction(self):
        """Test signal extraction with context."""
        test_input = '''
            @(posedge clk)
            disable iff (!rst_n)
            req |-> ##2 ack
        '''
        
        result = self.extractor.extract_signals_with_context(test_input)
        
        self.assertIn('clk', result['clock_signals'])
        self.assertIn('rst_n', result['reset_signals'])
        self.assertIn('req', result['data_signals'])
        self.assertIn('ack', result['data_signals'])

if __name__ == '__main__':
    unittest.main()
