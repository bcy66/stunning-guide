"""Test cases for SVA Parser."""

import unittest
import textwrap
from pathlib import Path
from src.parser import SVAParser

class TestSVAParser(unittest.TestCase):
    """Test cases for SystemVerilog Assertion Parser."""

    def setUp(self):
        self.parser = SVAParser()
        self.test_data_dir = Path(__file__).parent / 'test_data'

    def test_module_parsing(self):
        """Test module definition parsing."""
        test_cases = [
            {
                'name': 'basic_module',
                'input': '''
                    module test_module(
                        input clk,
                        output reg data
                    );
                    endmodule
                ''',
                'expected': {
                    'name': 'test_module',
                    'ports': [
                        {'direction': 'input', 'name': 'clk'},
                        {'direction': 'output', 'name': 'data'}
                    ]
                }
            },
            {
                'name': 'parameterized_module',
                'input': '''
                    module complex_module #(
                        parameter WIDTH = 32,
                        parameter DEPTH = 16
                    )(
                        input logic [WIDTH-1:0] data_in,
                        output logic [WIDTH-1:0] data_out
                    );
                    endmodule
                ''',
                'expected': {
                    'name': 'complex_module',
                    'parameters': [
                        {'name': 'WIDTH', 'value': '32'},
                        {'name': 'DEPTH', 'value': '16'}
                    ]
                }
            }
        ]

        for test_case in test_cases:
            with self.subTest(name=test_case['name']):
                content = textwrap.dedent(test_case['input'])
                result = self.parser.parse_module(content)
                for key, value in test_case['expected'].items():
                    self.assertEqual(result[key], value)

    def test_property_parsing(self):
        """Test property definition parsing."""
        test_cases = [
            {
                'name': 'basic_property',
                'input': '''
                    property p_basic;
                        @(posedge clk)
                        req |-> ack;
                    endproperty
                ''',
                'expected': {
                    'name': 'p_basic',
                    'signals': ['clk', 'req', 'ack']
                }
            },
            {
                'name': 'complex_property',
                'input': '''
                    property p_protocol;
                        @(posedge clk) disable iff (!rst_n)
                        req |=> ##[1:3] ack;
                    endproperty
                ''',
                'expected': {
                    'name': 'p_protocol',
                    'signals': ['clk', 'rst_n', 'req', 'ack']
                }
            }
        ]

        for test_case in test_cases:
            with self.subTest(name=test_case['name']):
                content = textwrap.dedent(test_case['input'])
                result = self.parser.parse_property(content)
                for key, value in test_case['expected'].items():
                    self.assertEqual(getattr(result, key), value)

    def test_assertion_parsing(self):
        """Test assertion statement parsing."""
        test_cases = [
            {
                'name': 'basic_assertion',
                'input': 'assert property(p_basic);',
                'expected': {
                    'type': 'assert',
                    'property_ref': 'p_basic'
                }
            },
            {
                'name': 'labeled_assertion',
                'input': '''
                    a_protocol: assert property(p_check)
                        else $error("Protocol violation");
                ''',
                'expected': {
                    'name': 'a_protocol',
                    'type': 'assert',
                    'property_ref': 'p_check',
                    'error_message': 'Protocol violation'
                }
            }
        ]

        for test_case in test_cases:
            with self.subTest(name=test_case['name']):
                content = textwrap.dedent(test_case['input'])
                result = self.parser.parse_assertion(content)
                for key, value in test_case['expected'].items():
                    self.assertEqual(getattr(result, key), value)

    def test_complete_file_parsing(self):
        """Test parsing of a complete SystemVerilog file."""
        test_file = self.test_data_dir / 'sample_sva.sv'
        result = self.parser.parse_file(test_file)
        
        self.assertIn('module', result)
        self.assertIn('properties', result)
        self.assertIn('assertions', result)
        self.assertIn('always_blocks', result)
        
        # Add specific checks based on test file content

if __name__ == '__main__':
    unittest.main()
