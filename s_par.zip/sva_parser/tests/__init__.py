"""Test package for SVA Parser.

This module initializes the test package and provides shared test utilities.
"""

import os
import sys
from pathlib import Path

# Add the src directory to Python path for test imports
src_path = str(Path(__file__).parent.parent / 'src')
if src_path not in sys.path:
    sys.path.insert(0, src_path)

# Shared test utilities
def get_test_data_path() -> Path:
    """Get the path to the test data directory.
    
    Returns:
        Path object pointing to the test_data directory
    """
    return Path(__file__).parent / 'test_data'

def load_test_file(filename: str) -> str:
    """Load content from a test data file.
    
    Args:
        filename: Name of the file in the test_data directory
        
    Returns:
        Content of the test file as string
        
    Raises:
        FileNotFoundError: If the test file doesn't exist
    """
    file_path = get_test_data_path() / filename
    with open(file_path, 'r') as f:
        return f.read()
    