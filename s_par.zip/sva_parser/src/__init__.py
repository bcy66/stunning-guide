"""SystemVerilog Assertion Parser.

A Python-based parser for SystemVerilog Assertions (SVA) that extracts and analyzes
property specifications, sequences, and assertions from SystemVerilog files.
"""

from .parser import SVAParser
from .signal_extractor import SignalExtractor
from .utils import get_line_numbers, clean_comments

__version__ = "0.1.0"
__all__ = ['SVAParser', 'SignalExtractor', 'get_line_numbers', 'clean_comments']
