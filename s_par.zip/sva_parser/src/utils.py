"""Utility functions for SVA Parser."""

import re
from typing import Tuple


def clean_comments(text: str) -> str:
    """Remove all comments from SystemVerilog text.

    Args:
        text: Input SystemVerilog text

    Returns:
        Text with all comments removed
    """
    # Remove multi-line comments
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)

    # Remove single-line comments
    text = re.sub(r"//.*$", "", text, flags=re.MULTILINE)

    # Clean up empty lines
    text = re.sub(r"\n\s*\n", "\n", text)

    return text


def get_line_numbers(text: str, match_start: int, match_text: str) -> Tuple[int, int]:
    """Calculate start and end line numbers for matched text.

    Args:
        text: Full source text
        match_start: Starting position of the match
        match_text: Matched text content

    Returns:
        Tuple of (start_line, end_line)
    """
    start_line = text.count("\n", 0, match_start) + 1
    end_line = start_line + match_text.count("\n")
    return start_line, end_line


def extract_between_keywords(text: str, start_keyword: str, end_keyword: str) -> str:
    """Extract text between two keywords, handling nested occurrences.

    Args:
        text: Input text
        start_keyword: Starting keyword
        end_keyword: Ending keyword

    Returns:
        Extracted text between keywords
    """
    stack = []
    start_pos = None
    current_pos = 0

    while current_pos < len(text):
        if text[current_pos:].startswith(start_keyword):
            if not stack:
                start_pos = current_pos
            stack.append(start_keyword)
            current_pos += len(start_keyword)
        elif text[current_pos:].startswith(end_keyword):
            if stack:
                stack.pop()
                if not stack:
                    return text[start_pos : current_pos + len(end_keyword)]
            current_pos += len(end_keyword)
        else:
            current_pos += 1

    raise ValueError(f"Unmatched {start_keyword}/{end_keyword} pair")
