"""Signal extraction functionality for SVA Parser."""

import re
from typing import Set, Dict, List


class SignalExtractor:
    """Handles extraction of signals from SystemVerilog assertions."""

    def __init__(self):
        # TODO: review the following functions and keywords, check if existed or missed
        self.sva_system_functions = {
            "$rose",
            "$fell",
            "$stable",
            "$past",
            "$future",
            "$changed",
            "$isunknown",
            "$onehot",
            "$onehot0",
            "$countones",
            "$sampled",
            "$fell_gclk",
            "$rose_gclk",
            "$steady_gclk",
            "$changing_gclk",
            "$left",
            "$right",
            "$low",
            "$high",
            "$increment",
            "$decrement",
            "$fatal",
            "$error",
            "$warning",
            "$info",
        }

        self.sva_keywords = {
            "throughout",
            "within",
            "until",
            "until_with",
            "s_until",
            "s_until_with",
            "accept_on",
            "reject_on",
            "sync_accept_on",
            "sync_reject_on",
            "first_match",
            "intersect",
            "expect",
            "covers",
            "triggered",
            "strong",
            "weak",
            "nexttime",
            "s_nexttime",
            "always",
            "eventually",
            "s_eventually",
            "never",
            "s_never",
        }

        self.sv_keywords = {
            "begin",
            "end",
            "if",
            "else",
            "case",
            "endcase",
            "posedge",
            "negedge",
            "or",
            "and",
            "not",
            "logic",
            "reg",
            "wire",
            "int",
            "bit",
            "byte",
            "shortint",
            "longint",
            "integer",
            "time",
            "assert",
            "assume",
            "cover",
            "property",
            "endproperty",
            "sequence",
            "endsequence",
            "disable",
            "iff",
            "matches",
            "inside",
        }

        self.exclude_words = (
            self.sva_system_functions | self.sva_keywords | self.sv_keywords
        )

        self.repetition_pattern = re.compile(
            r"\[\s*(?:\*|\+|\-\>|\=\>)\s*(?:\d+(?:\s*:\s*\d+)?)?\s*\]"
        )
        self.delay_pattern = re.compile(r"##\s*\d+(?:\s*:\s*\d+)?")
        self.identifier_pattern = re.compile(r"\b([a-zA-Z_][\w]*(?:\s*\[[^\]]+\])?)\b")

    def clean_sva_operators(self, text: str) -> str:
        """Remove SVA-specific operators and constructs from text.

        Args:
            text: Input SVA text

        Returns:
            Cleaned text with operators removed
        """
        text = self.repetition_pattern.sub(" ", text)
        text = self.delay_pattern.sub(" ", text)
        text = re.sub(r"\|\-\>", " ", text)
        text = re.sub(r"\|\=\>", " ", text)
        text = re.sub(r"[\[\]\(\)]", " ", text)
        text = re.sub(r"[!&|=<>~\^\+\-\*/%\?:;,]", " ", text)
        return text

    def extract_signals(self, text: str) -> Set[str]:
        """Extract signal names from SVA text.

        Args:
            text: Input SVA text

        Returns:
            Set of extracted signal names
        """
        cleaned_text = self.clean_sva_operators(text)
        signals = set()

        for match in self.identifier_pattern.finditer(cleaned_text):
            signal = match.group(1).strip()
            base_signal = signal.split("[")[0].strip()

            if (
                base_signal not in self.exclude_words
                and not base_signal.isdigit()
                and not any(c in base_signal for c in "+-*/%")
            ):
                signals.add(signal)

        return signals

    def extract_signals_with_context(self, text: str) -> Dict[str, Set[str]]:
        """Extract signals with their contextual information.

        Args:
            text: Input SVA text

        Returns:
            Dictionary with categorized signals
        """
        signals = {
            "clock_signals": set(),
            "reset_signals": set(),
            "control_signals": set(),
            "data_signals": set(),
        }

        # Extract clock signals
        clock_pattern = r"@\s*\(\s*(pos|neg)edge\s+(\w+)\s*\)"
        for match in re.finditer(clock_pattern, text):
            signals["clock_signals"].add(match.group(2))

        # Extract reset signals
        reset_pattern = r"disable\s+iff\s*\(\s*(!?\s*\w+)\s*\)"
        for match in re.finditer(reset_pattern, text):
            signals["reset_signals"].add(match.group(1).strip("!"))

        # Extract and categorize remaining signals
        all_signals = self.extract_signals(text)

        for signal in all_signals:
            if (
                signal not in signals["clock_signals"]
                and signal not in signals["reset_signals"]
            ):
                if re.search(rf"\b{signal}\b\s*(?:\!=|==|>=|<=|>|<)", text):
                    signals["control_signals"].add(signal)
                else:
                    signals["data_signals"].add(signal)

        return signals
