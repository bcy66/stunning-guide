"""Main parser implementation for SystemVerilog Assertions."""

import re
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict

from .signal_extractor import SignalExtractor
from .utils import clean_comments, get_line_numbers

# Configure logging
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


@dataclass
class SVModule:
    """SystemVerilog module representation."""

    name: str
    parameters: List[Dict[str, str]]
    ports: List[Dict[str, str]]
    original_code: str
    line_start: int
    line_end: int


@dataclass
class SVProperty:
    """SystemVerilog property representation."""

    name: str
    label: Optional[str]
    arguments: List[str]
    trigger_event: Optional[str]
    disable_condition: Optional[str]
    expression: str
    signals: List[str]
    original_code: str
    line_start: int
    line_end: int


@dataclass
class SVSequence:
    """SystemVerilog sequence representation."""

    name: str
    label: Optional[str]
    arguments: List[str]
    expression: str
    signals: List[str]
    original_code: str
    line_start: int
    line_end: int


@dataclass
class SVAssertion:
    """SystemVerilog assertion representation."""

    name: Optional[str]
    type: str  # assert/assume/cover
    property_ref: Optional[str]  # Name of referenced property, if any
    arguments: List[str]
    expression: Optional[str]  # Direct property expression, if any
    error_message: Optional[str]
    original_code: str
    line_start: int
    line_end: int


@dataclass
class SVAlways:
    """SystemVerilog always block representation."""

    type: str
    sensitivity: Optional[str]
    body: str
    signals: List[str]
    original_code: str
    line_start: int
    line_end: int


class SVAParser:
    """Parser for SystemVerilog Assertions and related constructs."""

    def __init__(self):
        self.signal_extractor = SignalExtractor()

        # Initialize regex patterns
        self._init_patterns()

    def _init_patterns(self):
        """Initialize all regex patterns used by the parser."""
        self.module_pattern = re.compile(
            r"module\s+(\w+)\s*"  # Module name
            r"(?:#\s*\(([\s\S]*?)\))?\s*"  # Optional parameter list
            r"\(([\s\S]*?)\);"  # Port list
            r"([\s\S]*?)"  # Module body
            r"endmodule",
            re.MULTILINE,
        )

        self.parameter_pattern = re.compile(r"parameter\s+(\w+)\s*=\s*([^,;\s]+)")

        self.port_pattern = re.compile(
            r"(input|output|inout)\s+(?:reg|wire|logic)?\s*"
            r"(?:\[[\w\-:]+\])?\s*"
            r"(\w+)"
        )

        self.always_pattern = re.compile(
            r"(always(?:_ff|_comb)?)\s*"  # Type
            r"(@\s*\([^)]+\))?\s*"  # Optional sensitivity list
            r"begin\s*"  # Begin
            r"([\s\S]*?)"  # Body
            r"end",  # End
            re.MULTILINE,
        )

        self.generate_pattern = re.compile(
            r"generate\s*([\s\S]*?)endgenerate", re.MULTILINE
        )

        self.property_pattern = re.compile(
            r"(?:(\w+)\s*:\s*)?"  # Optional label
            r"property\s+"  # property keyword
            r"(\w+)"  # property name
            r"(?:\s*\(([^)]*)\))?\s*"  # Optional arguments
            r"((?:[^e]|e(?!ndproperty))*?)"  # Everything until endproperty
            r"endproperty\s*(?:;)?",  # End of property
            re.MULTILINE | re.DOTALL,
        )

        self.sequence_pattern = re.compile(
            r"(?:(\w+)\s*:\s*)?"  # Optional label
            r"sequence\s+"  # sequence keyword
            r"(\w+)"  # sequence name
            r"(?:\s*\(([^)]*)\))?\s*"  # Optional arguments
            r"((?:[^e]|e(?!ndsequence))*?)"  # Everything until endsequence
            r"endsequence\s*(?:;)?",  # End of sequence
            re.MULTILINE | re.DOTALL,
        )

        self.assertion_pattern = re.compile(
            r"(?:(\w+)\s*:\s*)?"  # Optional name/label
            r"(assert|assume|cover)\s+"  # Type
            r"property\s*\("  # property keyword and opening parenthesis
            r"(.*?)"  # Everything until closing parenthesis, non-greedy
            r"\)\s*"  # Closing parenthesis
            r"((?:\s*else\s+\$error\s*\([^)]+\))?)?"  # Optional error message
            r"\s*;",  # End of assertion
            re.MULTILINE | re.DOTALL,
        )

    def parse_module(self, content: str) -> Dict[str, Any]:
        """Parse module definition including parameters and ports."""
        match = self.module_pattern.search(content)
        if not match:
            raise ValueError("No module definition found")

        name = match.group(1)
        params_text = match.group(2) or ""
        ports_text = match.group(3)

        # Parse parameters
        parameters = []
        for param_match in self.parameter_pattern.finditer(params_text):
            parameters.append(
                {"name": param_match.group(1), "value": param_match.group(2)}
            )

        # Parse ports
        ports = []
        for port_match in self.port_pattern.finditer(ports_text):
            ports.append(
                {"direction": port_match.group(1), "name": port_match.group(2)}
            )

        line_start, line_end = get_line_numbers(content, match.start(), match.group())

        return {
            "name": name,
            "parameters": parameters,
            "ports": ports,
            "original_code": match.group(),
            "line_start": line_start,
            "line_end": line_end,
        }

    def parse_always_blocks(self, content: str) -> List[Dict[str, Any]]:
        """Parse all always blocks in the module."""
        always_blocks = []

        for match in self.always_pattern.finditer(content):
            block_type = match.group(1)
            sensitivity = match.group(2)
            body = match.group(3)

            line_start, line_end = get_line_numbers(
                content, match.start(), match.group()
            )

            always_blocks.append(
                {
                    "type": block_type,
                    "sensitivity": sensitivity,
                    "body": body.strip(),
                    "signals": list(self.signal_extractor.extract_signals(body)),
                    "original_code": match.group(),
                    "line_start": line_start,
                    "line_end": line_end,
                }
            )

        return always_blocks

    def parse_generate_blocks(self, content: str) -> List[Dict[str, Any]]:
        """Parse generate blocks and their contents."""
        generate_blocks = []

        for match in self.generate_pattern.finditer(content):
            block_content = match.group(1)
            line_start, line_end = get_line_numbers(
                content, match.start(), match.group()
            )

            # Parse assertions within generate block
            assertions = []
            for assertion_match in self.assertion_pattern.finditer(block_content):
                assertion = self.parse_assertion(
                    content, assertion_match.start(), assertion_match.group()
                )
                assertions.append(asdict(assertion))

            generate_blocks.append(
                {
                    "content": block_content.strip(),
                    "assertions": assertions,
                    "original_code": match.group(),
                    "line_start": line_start,
                    "line_end": line_end,
                }
            )

        return generate_blocks

    def parse_property(
        self, content: str, match_start: int, match_text: str
    ) -> SVProperty:
        """Parse a SystemVerilog property definition while preserving comments."""
        match = self.property_pattern.search(match_text)
        if not match:
            raise ValueError(f"Invalid property format: {match_text}")

        label = match.group(1)
        name = match.group(2)
        arguments = self._parse_arguments(match.group(3))
        property_body = match.group(4)

        # Clean the property body for analysis
        cleaned_body = self._clean_expression(property_body)

        trigger_event = None
        trigger_match = re.search(r"@\s*\([^)]+\)", cleaned_body)
        if trigger_match:
            trigger_event = trigger_match.group(0)

        disable_condition = None
        disable_match = re.search(r"disable\s+iff\s*\([^)]+\)", cleaned_body)
        if disable_match:
            disable_condition = disable_match.group(0)

        # Extract the expression while maintaining structure
        expression = cleaned_body
        if trigger_event:
            expression = expression.replace(trigger_event, "")
        if disable_condition:
            expression = expression.replace(disable_condition, "")

        signals = list(self.signal_extractor.extract_signals(expression))

        line_start, line_end = get_line_numbers(content, match_start, match_text)

        return SVProperty(
            name=name,
            label=label,
            arguments=arguments,
            trigger_event=trigger_event,
            disable_condition=disable_condition,
            expression=expression.strip(),
            signals=signals,
            original_code=match_text,
            line_start=line_start,
            line_end=line_end,
        )

    def parse_sequence(
        self, content: str, match_start: int, match_text: str
    ) -> SVSequence:
        """Parse a SystemVerilog sequence definition."""
        match = self.sequence_pattern.search(match_text)
        if not match:
            raise ValueError(f"Invalid sequence format: {match_text}")

        label = match.group(1)
        name = match.group(2)
        arguments = self._parse_arguments(match.group(3))
        sequence_body = match.group(4)

        cleaned_body = self._clean_expression(sequence_body)
        signals = list(self.signal_extractor.extract_signals(cleaned_body))

        line_start, line_end = get_line_numbers(content, match_start, match_text)

        return SVSequence(
            name=name,
            label=label,
            arguments=arguments,
            expression=cleaned_body.strip(),
            signals=signals,
            original_code=match_text,
            line_start=line_start,
            line_end=line_end,
        )

    def parse_assertion(
        self, content: str, match_start: int, match_text: str
    ) -> SVAssertion:
        """Parse a SystemVerilog assertion statement.

        This method handles both referenced properties and direct property expressions:
        - Referenced: assert property(p_check(req, ack));
        - Direct: assert property(@(posedge clk) !$isunknown(input_sig));
        """
        match = self.assertion_pattern.search(match_text)
        if not match:
            raise ValueError(f"Invalid assertion format: {match_text}")

        label = match.group(1)
        type_ = match.group(2)
        prop_content = match.group(3).strip()
        error_text = match.group(4)

        # Handle property content with possible clock event
        trigger_event_match = re.match(r"@\s*\([^)]+\)\s*(.+)", prop_content)
        if trigger_event_match:
            # If there's a trigger event, get the actual property content after it
            prop_expression = trigger_event_match.group(1).strip()
        else:
            # If no clock event, use the entire content
            prop_expression = prop_content.strip()

        # Check if this is a referenced property or direct expression
        ref_match = re.match(r"(\w+)\s*\((.*)\)", prop_expression)
        if ref_match:
            # This is a referenced property
            property_ref = ref_match.group(1)
            arguments = self._parse_arguments(ref_match.group(2))
        else:
            # This is a direct property expression
            property_ref = None
            arguments = []

        # Handle error message if present
        error_message = None
        if error_text:
            error_match = re.search(r'\$error\s*\("([^"]+)"\)', error_text)
            if error_match:
                error_message = error_match.group(1)

        line_start, line_end = get_line_numbers(content, match_start, match_text)

        return SVAssertion(
            name=label,
            type=type_,
            property_ref=property_ref,
            arguments=arguments,
            expression=prop_expression if not property_ref else None,
            error_message=error_message,
            original_code=match_text,
            line_start=line_start,
            line_end=line_end,
        )

    def _parse_arguments(self, args_text: Optional[str]) -> List[str]:
        """Parse argument list handling nested structures."""
        if not args_text:
            return []

        arguments = []
        current_arg = []
        paren_level = 0
        in_string = False
        prev_char = ""

        for char in args_text:
            if char == '"' and prev_char != "\\":
                in_string = not in_string
                current_arg.append(char)
            elif not in_string:
                if char == "(":
                    paren_level += 1
                    current_arg.append(char)
                elif char == ")":
                    paren_level -= 1
                    current_arg.append(char)
                elif char == "," and paren_level == 0:
                    if current_arg:
                        arg = "".join(current_arg).strip()
                        if arg:
                            arguments.append(arg)
                    current_arg = []
                else:
                    current_arg.append(char)
            else:
                current_arg.append(char)
            prev_char = char

        if current_arg:
            arg = "".join(current_arg).strip()
            if arg:
                arguments.append(arg)

        if paren_level != 0:
            raise ValueError("Unmatched parentheses in arguments")

        return arguments

    def _clean_expression(self, text: str) -> str:
        """Clean an expression while preserving line structure."""
        # Replace single-line comments with empty lines
        text = re.sub(r"//[^\n]*\n", "\n", text)

        # Replace multi-line comments with equivalent number of newlines
        def replace_multiline_comment(match):
            return "\n" * match.group(0).count("\n")

        text = re.sub(r"/\*.*?\*/", replace_multiline_comment, text, flags=re.DOTALL)

        # Clean up excessive whitespace while preserving newlines
        text = re.sub(r"[ \t]+", " ", text)

        return text

    def parse_file(self, file_path: str) -> Dict[str, Any]:
        """Parse a SystemVerilog file and extract all components.

        Args:
            file_path: Path to SystemVerilog file

        Returns:
            Dictionary containing all parsed components

        Raises:
            FileNotFoundError: If file doesn't exist
            ValueError: If file contains invalid SystemVerilog syntax
        """
        try:
            with open(file_path, "r") as f:
                content = f.read()
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {str(e)}")
            raise

        results = {
            "file_path": str(file_path),
            "module": self.parse_module(content),
            "always_blocks": self.parse_always_blocks(content),
            "generate_blocks": self.parse_generate_blocks(content),
            "properties": [],
            "sequences": [],
            "assertions": [],
        }

        try:
            # Parse properties
            for match in self.property_pattern.finditer(content):
                property_obj = self.parse_property(
                    content, match.start(), match.group()
                )
                results["properties"].append(asdict(property_obj))

            # Parse sequences
            for match in self.sequence_pattern.finditer(content):
                sequence_obj = self.parse_sequence(
                    content, match.start(), match.group()
                )
                results["sequences"].append(asdict(sequence_obj))

            # Parse assertions
            for match in self.assertion_pattern.finditer(content):
                assertion_obj = self.parse_assertion(
                    content, match.start(), match.group()
                )
                results["assertions"].append(asdict(assertion_obj))

        except Exception as e:
            logger.error(f"Error parsing file {file_path}: {str(e)}")
            raise

        return results


def main():
    """Command-line entry point for the parser."""
    import argparse

    parser = argparse.ArgumentParser(
        description="Parse SystemVerilog Assertions and related components."
    )
    parser.add_argument("input_files", nargs="+", help="SystemVerilog input files")
    parser.add_argument("-o", "--output", help="Output JSON file", required=True)
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")

    args = parser.parse_args()

    if args.debug:
        logger.setLevel(logging.DEBUG)

    sva_parser = SVAParser()
    all_results = {
        "files": {},
        "summary": {
            "total_files": len(args.input_files),
            "successful_files": 0,
            "failed_files": 0,
        },
    }

    for input_file in args.input_files:
        try:
            logger.info(f"Processing file: {input_file}")
            results = sva_parser.parse_file(input_file)
            all_results["files"][input_file] = results
            all_results["summary"]["successful_files"] += 1

        except Exception as e:
            all_results["summary"]["failed_files"] += 1
            logger.error(f"Error processing {input_file}: {str(e)}")
            all_results["files"][input_file] = {"error": str(e)}

    try:
        with open(args.output, "w") as f:
            json.dump(all_results, f, indent=2)
        logger.info(f"Results written to: {args.output}")

    except Exception as e:
        logger.error(f"Error writing output file: {str(e)}")
        return 1

    return 0 if all_results["summary"]["failed_files"] == 0 else 1


if __name__ == "__main__":
    exit(main())
